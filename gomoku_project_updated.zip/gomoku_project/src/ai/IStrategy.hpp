#ifndef GOMOKU_AI_ISTRATEGY_HPP
#define GOMOKU_AI_ISTRATEGY_HPP

#include "../core/GameState.hpp"

class IStrategy {
public:
    virtual ~IStrategy() {}
    virtual Move chooseMove(const GameState& s, Cell aiColor) = 0;
};

#endif
