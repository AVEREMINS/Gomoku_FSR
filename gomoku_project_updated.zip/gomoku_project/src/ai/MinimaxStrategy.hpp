#ifndef GOMOKU_AI_MINIMAXSTRATEGY_HPP
#define GOMOKU_AI_MINIMAXSTRATEGY_HPP

// NOTE: Minimax level is temporarily disabled in Game.cpp.
// To re-enable:
// 1) add #include "MinimaxStrategy.hpp" in Game.cpp
// 2) compile MinimaxStrategy.cpp
// 3) in Game::setupPlayers() map difficulty 3 to MinimaxStrategy instead of GreedyStrategy.

#include "IStrategy.hpp"

class MinimaxStrategy : public IStrategy {
public:
    explicit MinimaxStrategy(int depth) : depth_(depth) {}
    Move chooseMove(const GameState& s, Cell aiColor);

private:
    int depth_;

    int hasAnyStone(const Board& b) const;
    int isNearStone(const Board& b, int x, int y) const;
    int genCandidates(const Board& b, Move* outMoves, int maxCount) const;

    int evaluate(const GameState& s, Cell aiColor) const;
    int minimax(GameState& s, int depth, int alpha, int beta, Cell aiColor, int maximizing);
};

#endif
