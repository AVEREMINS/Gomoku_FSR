#ifndef GOMOKU_AI_RANDOMSTRATEGY_HPP
#define GOMOKU_AI_RANDOMSTRATEGY_HPP

#include "IStrategy.hpp"

class RandomStrategy : public IStrategy {
public:
    Move chooseMove(const GameState& s, Cell aiColor);
};

#endif
