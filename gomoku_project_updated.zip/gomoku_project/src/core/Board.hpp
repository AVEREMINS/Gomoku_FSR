#ifndef GOMOKU_CORE_BOARD_HPP
#define GOMOKU_CORE_BOARD_HPP

#include "Types.hpp"

class Board {
public:
    // We support 13/15/19 sizes, so the max must be at least 19.
    enum { MAX_N = 19 };

    explicit Board(int n = 15);

    int size() const;

    int inside(int x, int y) const;
    Cell at(int x, int y) const;

    int isLegal(const Move& m) const;
    void place(const Move& m, Cell who);
    void undo(const Move& m);

    int full() const;
    int checkWinFrom(const Move& last, Cell who) const;

private:
    int n_;
    Cell g_[MAX_N][MAX_N];

    int countDir(const Move& from, Cell who, int dx, int dy) const;
};

#endif
