#ifndef GOMOKU_CORE_ERROR_HPP
#define GOMOKU_CORE_ERROR_HPP

#include <exception>

// Simple error hierarchy for the whole project.
// We keep messages as const char* to avoid std::string usage.
class Error : public std::exception {
public:
    explicit Error(const char* msg) : msg_(msg) {}
    const char* what() const noexcept override { return msg_; }
private:
    const char* msg_;
};

class LogicError : public Error { public: explicit LogicError(const char* m) : Error(m) {} };
class InvalidMoveError : public Error { public: explicit InvalidMoveError(const char* m) : Error(m) {} };
class PresenterError : public Error { public: explicit PresenterError(const char* m) : Error(m) {} };

#endif
