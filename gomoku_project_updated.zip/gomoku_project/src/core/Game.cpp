#include "Game.hpp"
#include "../ai/RandomStrategy.hpp"
#include "../ai/GreedyStrategy.hpp"
// #include "../ai/MinimaxStrategy.hpp" // TEMPORARILY DISABLED

#include <stdio.h>

Game::Game(int defaultBoardSize)
: s_(defaultBoardSize), pBlack_(0), pWhite_(0), currentBoardSize_(defaultBoardSize) {}

Game::~Game() {
    if (pBlack_ != 0) { delete pBlack_; pBlack_ = 0; }
    if (pWhite_ != 0) { delete pWhite_; pWhite_ = 0; }
}

void Game::setStatus(char* dst, int cap, const char* text) {
    if (cap <= 0) return;
    dst[0] = 0;
    if (text == 0) return;
    snprintf(dst, (size_t)cap, "%s", text);
}

void Game::setupPlayers(Presenter& presenter) {
    Cell humanColor = CELL_BLACK;
    int difficulty = 2; // 1=Random, 2=Greedy, 3=Minimax (disabled)
    int boardSize = currentBoardSize_;

    presenter.selectSettings(&humanColor, &difficulty, &boardSize);

    currentBoardSize_ = boardSize;
    s_ = GameState(currentBoardSize_);

    if (pBlack_ != 0) { delete pBlack_; pBlack_ = 0; }
    if (pWhite_ != 0) { delete pWhite_; pWhite_ = 0; }

    IStrategy* sBlack = 0;
    IStrategy* sWhite = 0;

    if (difficulty == 1) { sBlack = new RandomStrategy(); sWhite = new RandomStrategy(); }
    if (difficulty >= 2) { sBlack = new GreedyStrategy(); sWhite = new GreedyStrategy(); }

    // To re-enable minimax level, do:
    // if (difficulty >= 3) { sBlack = new MinimaxStrategy(3); sWhite = new MinimaxStrategy(3); }

    if (humanColor == CELL_BLACK) pBlack_ = new HumanPlayer();
    else pBlack_ = new AiPlayer(CELL_BLACK, sBlack);

    if (humanColor == CELL_WHITE) pWhite_ = new HumanPlayer();
    else pWhite_ = new AiPlayer(CELL_WHITE, sWhite);

    // If the player is human, we must free unused strategies.
    if (humanColor == CELL_BLACK) { if (sBlack != 0) { delete sBlack; sBlack = 0; } }
    if (humanColor == CELL_WHITE) { if (sWhite != 0) { delete sWhite; sWhite = 0; } }
}

void Game::applyMoveOrThrow(const Move& m) {
    if (!s_.board.isLegal(m)) {
        throw InvalidMoveError("Invalid move: out of bounds or cell is occupied.");
    }
    s_.board.place(m, s_.turn);
    s_.history[s_.historyCount] = m;
    s_.historyCount = s_.historyCount + 1;
}

void Game::run(Presenter& presenter) {
    char status[200];

    int quitAll = 0;

    while (!presenter.shouldQuit() && !quitAll) {
        // Menu + settings
        try {
            setupPlayers(presenter);
        } catch (const PresenterError&) {
            quitAll = 1;
        }

        if (!quitAll) {
            setStatus(status, 200, "Gomoku: five in a row. LMB - move. ESC - quit.");

            int gameOver = 0;
            int goMenu = 0;

            while (!presenter.shouldQuit() && !gameOver && !goMenu) {
                presenter.draw(s_, status);

                // Hotkeys
                if (presenter.shouldOpenMenu()) {
                    goMenu = 1;
                } else if (presenter.shouldRestart()) {
                    s_ = GameState(currentBoardSize_);
                    presenter.showMessage("Restarted.");
                } else {
                    Player* cur = (s_.turn == CELL_BLACK) ? pBlack_ : pWhite_;

                    try {
                        Move m = cur->getMove(s_, presenter);
                        applyMoveOrThrow(m);

                        if (s_.board.checkWinFrom(m, s_.turn)) {
                            if (s_.turn == CELL_BLACK) {
                                setStatus(status, 200, "BLACK wins! ENTER - menu, ESC - quit.");
                            } else {
                                setStatus(status, 200, "WHITE wins! ENTER - menu, ESC - quit.");
                            }
                            gameOver = 1;
                        } else if (s_.board.full()) {
                            setStatus(status, 200, "DRAW! ENTER - menu, ESC - quit.");
                            gameOver = 1;
                        } else {
                            s_.turn = Opponent(s_.turn);
                        }
                    } catch (const InvalidMoveError& e) {
                        presenter.showMessage(e.what());
                    }
                }
            }

            // End screen: ENTER -> menu
            if (!presenter.shouldQuit() && gameOver) {
                int backToMenu = 0;
                while (!presenter.shouldQuit() && !backToMenu) {
                    presenter.draw(s_, status);
                    if (presenter.shouldMenu()) backToMenu = 1;
                }
            }
        }
    }
}
