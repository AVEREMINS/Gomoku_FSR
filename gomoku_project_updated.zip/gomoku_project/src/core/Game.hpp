#ifndef GOMOKU_CORE_GAME_HPP
#define GOMOKU_CORE_GAME_HPP

#include "../ui/Presenter.hpp"
#include "GameState.hpp"
#include "Player.hpp"
#include "Error.hpp"

class Game {
public:
    explicit Game(int defaultBoardSize);
    ~Game();

    void run(Presenter& presenter);

private:
    GameState s_;
    Player* pBlack_;
    Player* pWhite_;

    int currentBoardSize_;

    void setupPlayers(Presenter& presenter);
    void applyMoveOrThrow(const Move& m);

    void setStatus(char* dst, int cap, const char* text);
};

#endif
