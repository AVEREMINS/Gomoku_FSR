#ifndef GOMOKU_CORE_GAMESTATE_HPP
#define GOMOKU_CORE_GAMESTATE_HPP

#include "Board.hpp"

struct GameState {
    Board board;
    Cell turn;

    Move history[Board::MAX_N * Board::MAX_N];
    int historyCount;

    explicit GameState(int n = 15) : board(n), turn(CELL_BLACK), historyCount(0) {}
};

#endif
