#include <time.h>
#include <stdlib.h>

#include "core/Game.hpp"
#include "ui/RaylibPresenter.hpp"
#include "core/Error.hpp"

int main() {
    srand((unsigned)time(0));

    try {
        RaylibPresenter presenter;
        Game game(15);
        game.run(presenter);
        return 0;
    } catch (const Error&) {
        return 1;
    } catch (...) {
        return 2;
    }
}
