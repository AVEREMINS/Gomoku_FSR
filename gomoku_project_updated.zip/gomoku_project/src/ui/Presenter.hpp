#ifndef GOMOKU_UI_PRESENTER_HPP
#define GOMOKU_UI_PRESENTER_HPP

#include "../core/GameState.hpp"

class Presenter {
public:
    virtual ~Presenter() {}

    // Menu: choose human color, AI difficulty, and board size.
    virtual void selectSettings(Cell* humanColor, int* difficulty, int* boardSize) = 0;

    // Render current state.
    virtual void draw(const GameState& s, const char* status) = 0;

    // Human input (blocking until click).
    virtual Move pollHumanMove(const GameState& s) = 0;

    // Small text notifications.
    virtual void showMessage(const char* msg) = 0;

    // Exit signals.
    virtual int shouldQuit() const = 0;   // ESC / window close
    virtual int shouldMenu() const = 0;   // ENTER (on end screen)
    virtual int shouldRestart() const = 0;// R
    virtual int shouldOpenMenu() const = 0;// M (during match)
};

#endif
