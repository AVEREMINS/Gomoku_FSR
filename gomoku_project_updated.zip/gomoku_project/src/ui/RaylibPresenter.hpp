#ifndef GOMOKU_UI_RAYLIBPRESENTER_HPP
#define GOMOKU_UI_RAYLIBPRESENTER_HPP

#include "Presenter.hpp"
#include "../core/Error.hpp"

#include "raylib.h"

class RaylibPresenter : public Presenter {
public:
    RaylibPresenter();
    ~RaylibPresenter();

    void selectSettings(Cell* humanColor, int* difficulty, int* boardSize);
    void draw(const GameState& s, const char* status);
    Move pollHumanMove(const GameState& s);

    void showMessage(const char* msg);

    int shouldQuit() const;
    int shouldMenu() const;
    int shouldRestart() const;
    int shouldOpenMenu() const;

private:
    int winW_;
    int winH_;
    int margin_;
    int cellPx_;

    char msg_[256];
    int msgFrames_;

    void computeLayout(int n);
    Vector2 cellCenter(int x, int y) const;
    int mouseToCell(const GameState& s, Move* out) const;
};

#endif
